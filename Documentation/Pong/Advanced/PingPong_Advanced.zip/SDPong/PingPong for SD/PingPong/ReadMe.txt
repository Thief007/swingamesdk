----------------------------------------
SwinGameSDK version 1.1.3
----------------------------------------
Go to http://www.swingame.com/
for documentations and details.

The SDK is released under GPL version 2
----------------------------------------
Imports SwinGame

Module GameLogic

	Const FIELD_TOP = 7
	Const FIELD_BOTTOM = 452
	Const FIELD_LEFT = 7
	Const FIELD_RIGHT = 794
	Const PADDLE_OFFSET = 50

    Private ScoreRed As Integer
    Private ScorePurple As Integer
    Private Ball As Sprite
    Private PurplePaddle As Sprite
    Private RedPaddle As Sprite

    Sub PerformCollision(ByVal ball As Sprite, ByVal paddle As Sprite)
        Dim hitLine, lines() As LineSegment
        Dim vectTemp As Vector
        Dim shortest As Double
        Dim temp, ballCenter As Point2D
        Dim pdlRect As Rectangle = Shapes.CreateRectangle(paddle)
        Dim ballRect As Rectangle = Shapes.CreateRectangle(ball)

        lines = Shapes.LinesFromRect(pdlRect)

        'Get the vector to move the ball sprite out of the paddle sprite
        Dim mv As Vector = Physics.VectorOutOfRectFromRect(ballRect, pdlRect, ball.Movement.AsVector())

        'Move the ball out of the paddle
        Graphics.MoveSprite(ball, mv)

        ballCenter = Shapes.CenterPoint(ball)

        shortest = ball.Width 'it must be < than this...

        'find the closest point
        For i As Integer = 0 To 3
            temp = Shapes.ClosestPointOnLine(ballCenter, lines(i))
            vectTemp = Physics.VectorFromPoints(ballCenter, temp)

            If Physics.Magnitude(vectTemp) < shortest Then
                shortest = Physics.Magnitude(vectTemp)
                hitLine = lines(i)
            End If
        Next

        Physics.CircleCollisionWithLine(ball, hitLine)
    End Sub

	Sub StartUpGame()
		'Position of ball
        ball.X = 400 - ball.Width / 2
        ball.Y = 240 - ball.Height / 2

		ball.Movement.Y = 0
        'Send ball... left or right
		if Rnd() < 0.5 then 
			ball.Movement.X = -2.5
		else
			ball.Movement.X = 2.5
		end if

        'Position of paddle
        purplePaddle.X = FIELD_RIGHT - PADDLE_OFFSET - purplePaddle.Width
        purplePaddle.Y = 240 - purplePaddle.Height / 2

        'Position of paddle
        redPaddle.X = FIELD_LEFT + PADDLE_OFFSET
        redPaddle.Y = 240 - redPaddle.Height / 2

		'Play 3..2..1..
		Dim i as Integer
		
		for i = 3 to 1 step -1
			DrawGame()
			Text.DrawText(i.ToString(), Color.Black, GameFont("ArialLarge"), 370, 200)
			Audio.PlaySoundEffect(GameSound("beep"))
			Core.RefreshScreen()
			Core.Sleep(300)
		next
	End Sub
	
	Sub DrawGame()
		'Drawing the game elements
	    Graphics.DrawBitmap(GameImage("table"), 0, 0)
	    Graphics.DrawSprite(ball)
	    Graphics.DrawSprite(PurplePaddle)
	    Graphics.DrawSprite(RedPaddle)

	    'Putting the score up
	    Text.DrawText(ScoreRed.ToString(), Color.White, GameFont("ArialLarge"), 21, 511)
	    Text.DrawText(ScorePurple.ToString(), Color.White, GameFont("ArialLarge"), 650, 511)
	End Sub
	
	Sub HandleInput()
		'Clear Movement
		redPaddle.Movement.X = 0
		redPaddle.Movement.Y = 0
		purplePaddle.Movement.X = 0
		purplePaddle.Movement.Y = 0
	
	    'moves the paddle when user presses left and right keys
	    If Input.IsKeyPressed(SwinGame.Keys.VK_A) Then
	        redPaddle.Movement.Y = -2
	    End If

	    If Input.IsKeyPressed(SwinGame.Keys.VK_Z) Then
	        redPaddle.Movement.Y = 2
	    End If

	    If Input.IsKeyPressed(SwinGame.Keys.VK_UP) Then
	        purplePaddle.Movement.Y = -2
	    End If

	    If Input.IsKeyPressed(SwinGame.Keys.VK_DOWN) Then
	        purplePaddle.Movement.Y = 2
	    End If
	
		'Move Paddles
		Graphics.MoveSprite(purplePaddle)
		Graphics.MoveSprite(redPaddle)
	
        'stops the paddles moving off the screen
        If purplepaddle.Y < FIELD_TOP Then
            purplepaddle.Y = FIELD_TOP
        End If

        If purplepaddle.Y + purplepaddle.Height > FIELD_BOTTOM Then
            purplepaddle.Y = FIELD_BOTTOM - purplepaddle.Height
        End If

        If redpaddle.Y < FIELD_TOP Then
            redpaddle.Y = FIELD_TOP
        End If

        If redpaddle.Y + redPaddle.Height > FIELD_BOTTOM Then
            redpaddle.Y = FIELD_BOTTOM - redPaddle.Height
        End If
	End Sub
	
	Sub ShowScoreScreen()
		DrawGame()
		Text.DrawText("SCORE !!!", Color.Black, GameFont("ArialLarge"), 220, 200)
		Core.RefreshScreen()
		Core.Sleep(2000)
	End Sub
	
	Sub UpdateBall()
	    'Tests to see if ball has hit an outside border
	    'bounces the ball off the wall
	    If ball.Y + ball.Height > FIELD_BOTTOM Then
			ball.Y = FIELD_BOTTOM - ball.Height
	        ball.Movement.Y = -ball.Movement.Y
	        Audio.PlaySoundEffect(GameSound("bounce"))
	    End If

	    If ball.X + ball.Width > FIELD_RIGHT Then 'if the ball has hit the rhs border
			ball.X = FIELD_RIGHT - ball.Width
	        ball.Movement.X = -ball.Movement.X 'reverse the x movement
	        Audio.PlaySoundEffect(GameSound("backwall"))
	        ScoreRed = ScoreRed + 1
	
			ShowScoreScreen()
			StartUpGame()
	    End If

	    If ball.X < FIELD_LEFT Then
			ball.X = FIELD_LEFT
	        ball.Movement.X = -ball.Movement.X
	        Audio.PlaySoundEffect(GameSound("backwall"))
	        ScorePurple = ScorePurple + 1
	
			ShowScoreScreen()
			StartUpGame()
	    End If

	    If ball.Y < FIELD_TOP Then
			ball.Y = FIELD_TOP
	        ball.Movement.Y = -ball.Movement.Y
	        Audio.PlaySoundEffect(GameSound("bounce"))
	    End If
	
	    Graphics.MoveSprite(ball)
	End Sub
	
	Sub CheckCollisions()
	    'Ball collision with paddles
	    If Physics.HaveSpritesCollided(ball, purplepaddle) Then
	        Audio.PlaySoundEffect(GameSound("hit"))
	        PerformCollision(ball, purplePaddle)
	
			'Add spin (30% of paddle movement)
			ball.Movement.Y = ball.Movement.Y + 0.3 * purplePaddle.Movement.Y
		
			'Accelerate by 5%
			ball.Movement.Y = ball.Movement.Y * 1.05
			ball.Movement.X = ball.Movement.X * 1.05
	    End If

	    If Physics.HaveSpritesCollided(ball, redpaddle) Then
	        PerformCollision(ball, redPaddle)
	        Audio.PlaySoundEffect(GameSound("hit"))

			'Add spin (30% of paddle movement)
			ball.Movement.Y = ball.Movement.Y + 0.3 * redPaddle.Movement.Y
		
			'Accelerate by 5%
			ball.Movement.Y = ball.Movement.Y * 1.05
			ball.Movement.X = ball.Movement.X * 1.05
	    End If
	
		If Physics.Magnitude(ball.Movement.AsVector) > Ball.Width Then
			Dim v As Vector
            v = Physics.LimitMagnitude(Ball.Movement.AsVector, Ball.Width)
			ball.Movement.SetTo(v)
		End If
	End Sub
	
    Public Sub Main()
		Randomize(Now.Second)
		
        'Opens a new Graphics Window
        Core.OpenGraphicsWindow("Game", 800, 600)

        'Open Audio Device
        Audio.OpenAudio()

        'Loads all the game's resources
        LoadResources()

        ScoreRed = 0
        ScorePurple = 0

		'Create balls and paddles
        ball = Graphics.CreateSprite(GameImage("ball"))
        purplepaddle = Graphics.CreateSprite(GameImage("purplepaddle"))
        redpaddle = Graphics.CreateSprite(GameImage("redpaddle"))

		Audio.PlayMusic(GameMusic("amb"))

		StartUpGame()

        'Game Loop
        Do
			HandleInput()
			UpdateBall()

			CheckCollisions()
			
			DrawGame()

            'Refreshes the Screen and Processes Input Events
            Core.RefreshScreen()
            Core.ProcessEvents()

            'Finishes the game loop when the user closes the window
        Loop Until SwinGame.Core.WindowCloseRequested() = True

        'Free Resources and Close Audio, to end the program.
        FreeResources()
        Audio.CloseAudio()

    End Sub

End Module

Place your game resources here. This would include the following...

- Fonts (use true type fonts)
- Images (bitmaps, png, jpeg, etc.)
- Sounds (wav, ogg, mp3, etc.)

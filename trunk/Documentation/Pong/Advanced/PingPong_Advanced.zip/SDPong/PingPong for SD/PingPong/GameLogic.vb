Imports SwinGame

Module GameLogic

	Const FIELD_TOP = 7
	Const FIELD_BOTTOM = 452
	Const FIELD_LEFT = 7
	Const FIELD_RIGHT = 794
	Const PADDLE_OFFSET = 50

    'TODO: Add score variables here...
    Private Ball As Sprite
    Private PurplePaddle As Sprite
    Private RedPaddle As Sprite

    Sub PerformCollision(ByVal ball As Sprite, ByVal paddle As Sprite)
        Dim hitLine, lines() As LineSegment
        Dim vectTemp As Vector
        Dim shortest As Double
        Dim temp, ballCenter As Point2D
        Dim pdlRect As Rectangle = Shapes.CreateRectangle(paddle)
        Dim ballRect As Rectangle = Shapes.CreateRectangle(ball)

        lines = Shapes.LinesFromRect(pdlRect)

        'Get the vector to move the ball sprite out of the paddle sprite
        Dim mv As Vector = Physics.VectorOutOfRectFromRect(ballRect, pdlRect, ball.Movement.AsVector())

        'Move the ball out of the paddle
        Graphics.MoveSprite(ball, mv)

        ballCenter = Shapes.CenterPoint(ball)

        shortest = ball.Width 'it must be < than this...

        'find the closest point
        For i As Integer = 0 To 3
            temp = Shapes.ClosestPointOnLine(ballCenter, lines(i))
            vectTemp = Physics.VectorFromPoints(ballCenter, temp)

            If Physics.Magnitude(vectTemp) < shortest Then
                shortest = Physics.Magnitude(vectTemp)
                hitLine = lines(i)
            End If
        Next

        Physics.CircleCollisionWithLine(ball, hitLine)
    End Sub

	Sub StartUpGame()
		'Position of ball
        ball.X = 400 - ball.Width / 2
        ball.Y = 240 - ball.Height / 2

        Ball.Movement.Y = 0

        'TODO: Change the following line to move the ball left or right...
        Ball.Movement.X = 0

        'Position of paddle
        purplePaddle.X = FIELD_RIGHT - PADDLE_OFFSET - purplePaddle.Width
        purplePaddle.Y = 240 - purplePaddle.Height / 2

        'Position of paddle
        redPaddle.X = FIELD_LEFT + PADDLE_OFFSET
        redPaddle.Y = 240 - redPaddle.Height / 2

		'Play 3..2..1..
		Dim i as Integer
		
		for i = 3 to 1 step -1
			DrawGame()
			Text.DrawText(i.ToString(), Color.Black, GameFont("ArialLarge"), 370, 200)
			Audio.PlaySoundEffect(GameSound("beep"))
			Core.RefreshScreen()
			Core.Sleep(300)
		next
	End Sub
	
	Sub DrawGame()
        'Drawing the game elements
        Graphics.ClearScreen()

        'TODO: Draw the background image here...

	    Graphics.DrawSprite(ball)
	    Graphics.DrawSprite(PurplePaddle)
	    Graphics.DrawSprite(RedPaddle)

        'Putting the score up
        'TODO: Add score drawing here
    End Sub
	
	Sub HandleInput()
		'Clear Movement
		redPaddle.Movement.X = 0
		redPaddle.Movement.Y = 0
		purplePaddle.Movement.X = 0
		purplePaddle.Movement.Y = 0
	
	    'moves the paddle when user presses left and right keys
	    If Input.IsKeyPressed(SwinGame.Keys.VK_A) Then
	        redPaddle.Movement.Y = -2
	    End If

	    If Input.IsKeyPressed(SwinGame.Keys.VK_Z) Then
	        redPaddle.Movement.Y = 2
	    End If

        'TODO: Add the code to move the PurplePaddle here

		'Move Paddles
		Graphics.MoveSprite(purplePaddle)
		Graphics.MoveSprite(redPaddle)
	
        'stops the paddles moving off the screen

        'TODO: Add code here to stop purple moving off the screen... 

        If redpaddle.Y < FIELD_TOP Then
            redpaddle.Y = FIELD_TOP
        End If

        If redpaddle.Y + redPaddle.Height > FIELD_BOTTOM Then
            redpaddle.Y = FIELD_BOTTOM - redPaddle.Height
        End If
	End Sub

    Sub UpdateBall()
        'Tests to see if ball has hit an outside border
        'bounces the ball off the wall
        If Ball.Y + Ball.Height > FIELD_BOTTOM Then
            Ball.Y = FIELD_BOTTOM - Ball.Height
            Ball.Movement.Y = -Ball.Movement.Y
            'TODO: Add the "bounce" sound effect to this code
        End If

        If Ball.Y < FIELD_TOP Then
            Ball.Y = FIELD_TOP
            Ball.Movement.Y = -Ball.Movement.Y
            'TODO: Add the "bounce" sound effect to this code
        End If

        If Ball.X + Ball.Width > FIELD_RIGHT Then 'if the ball has hit the rhs border
            Ball.X = FIELD_RIGHT - Ball.Width
            Ball.Movement.X = -Ball.Movement.X 'reverse the x movement
            'TODO: Add the "bounce" sound effect to this code
			'TODO: Change to "backwall" sound effect
			
            'TODO: Increase red score here
			'TODO: Add calls to ShowScoreScreen and StartUpGame here
        End If

        If Ball.X < FIELD_LEFT Then
            Ball.X = FIELD_LEFT
            Ball.Movement.X = -Ball.Movement.X
            'TODO: Add the "bounce" sound effect to this code
			'TODO: Change to "backwall" sound effect
			
            'TODO: Increase purple score here
			'TODO: Add calls to ShowScoreScreen and StartUpGame here
        End If

        Graphics.MoveSprite(Ball)
    End Sub
	
    'TODO: Add the code to spin and accelerate the ball
    Sub CheckCollisions()
        'Ball collision with paddles
        If Physics.HaveSpritesCollided(Ball, PurplePaddle) Then
            Audio.PlaySoundEffect(GameSound("hit"))
            PerformCollision(Ball, PurplePaddle)

            'Add spin (30% of paddle movement)

            'Accelerate by 5%
        End If

        If Physics.HaveSpritesCollided(Ball, RedPaddle) Then
            PerformCollision(Ball, RedPaddle)
            Audio.PlaySoundEffect(GameSound("hit"))

            'Add spin (30% of paddle movement)

            'Accelerate by 5%
        End If

        If Physics.Magnitude(Ball.Movement.AsVector) > Ball.Width Then
            Dim v As Vector
            v = Physics.LimitMagnitude(Ball.Movement.AsVector, Ball.Width)
            Ball.Movement.SetTo(v)
        End If
    End Sub
	
    Public Sub Main()
		Randomize(Now.Second)
		
        'Opens a new Graphics Window
        Core.OpenGraphicsWindow("Game", 800, 600)

        'Open Audio Device
        Audio.OpenAudio()

        'Loads all the game's resources
        LoadResources()

        'TODO: Initialise ScoreRed and ScorePurple here ...

		'Create balls and paddles
        Ball = Graphics.CreateSprite(GameImage("ball"))
        PurplePaddle = Graphics.CreateSprite(GameImage("purplepaddle"))
        RedPaddle = Graphics.CreateSprite(GameImage("redpaddle"))

        'TODO: Play music here...

		StartUpGame()

        'Game Loop
        Do
			HandleInput()
			UpdateBall()

            'TODO: Call CheckCollisions here...

			DrawGame()

            'Refreshes the Screen and Processes Input Events
            Core.RefreshScreen()
            Core.ProcessEvents()

            'Finishes the game loop when the user closes the window
        Loop Until SwinGame.Core.WindowCloseRequested() = True

        'Free Resources and Close Audio, to end the program.
        FreeResources()
        Audio.CloseAudio()

    End Sub

End Module
